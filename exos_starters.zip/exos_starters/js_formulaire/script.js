(function() {

  //
  // Tâche 1 - Validation email
  //

  // @TODO

  //
  // Tâche 2 - Affiche un champ optionnel
  //

  // @TODO

  //
  // Fonction utilitaire
  //

  // Fonction de validation email
  function validateEmail(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
  }

}());
