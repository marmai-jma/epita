// Sous-total
var subtotal = (13 + 1) * 5; // Le Sous-total est 70

// Calculer les frais d'envoi (15% de subtotal)
// Variable `shipping`

// Calculer le total
// Variable `total`


// Afficher les variables à l'écran
