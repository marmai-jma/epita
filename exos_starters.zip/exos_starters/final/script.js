$(document).ready(function() {

  var firstName = 'toto',
      apiKey = 'PKYMVKxessUwaTEnpWXEtkqME062neJH',
      baseUrl = 'https://api.mongolab.com/api/1/databases/toulouse'
      databaseUrl = baseUrl + '/collections/' + firstName + '?apiKey=' + apiKey;




  /**
   * Charge les commentaires précédemment enregistrés.
   */
  function loadComments() {
  }

  /**
   * Insère le nouveau commentaire dans le DOM.
   */
  function displayComment(comment) {

  }

  /**
   * Enregistre un nouveau commentaire sur Mongolab grâce à Ajax
   */
  function saveComment(comment) {

  }

});
