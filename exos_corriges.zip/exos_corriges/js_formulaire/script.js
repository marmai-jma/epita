(function() {

  //
  // Tâche 1 - Validation email
  //

  var eltEmail = document.getElementById('email');
  eltEmail.addEventListener('blur', checkEmail, false);

  function checkEmail(evt) {
    var email = evt.target.value;
    if (validateEmail(email)) {
      // Si l'e-mail est valide, retire la classe 'incorrect'
      // éventuellement présente sur le champ email.
      evt.target.className = '';
    }
    else {
      // Si l'e-mail n'est pas valide,
      // ajoute la classe 'incorrect' au champ email.
      evt.target.className = 'incorrect';
    }
  }

  //
  // Tâche 2 - Affiche un champ optionnel
  //

  var eltSubscribe = document.getElementById('subscribe');
  eltSubscribe.addEventListener('change', toggleOptionalField, false);

  // Balise <p> contenant le champ Fréquence ET son label.
  var pFrequency = document.querySelector('#frequency').parentNode;

  function toggleOptionalField(evt) {
    if (evt.target.checked) {
      pFrequency.className = '';
    }
    else {
      pFrequency.className = 'invisible';
    }
  }

  // Intialise la visibilité du champ optionnel.
  if (!eltSubscribe.checked) {
    pFrequency.className = 'invisible';
  }

  //
  // Fonction utilitaire
  //

  // Fonction de validation email
  function validateEmail(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
  }

}());
