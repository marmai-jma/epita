﻿(function() {

  var submitButton = document.getElementById('submit_btn'),
      inputField = document.getElementById('first_name'),
      displaySavedName = document.getElementById('saved_first_name');

  // Un prénom a-t-il été sauvegardé précédemment ?
  var savedName = localStorage.getItem('first_name');
  if (savedName) {
    displaySavedName.innerText = savedName;
  }
  else {
    displaySavedName.innerText = 'Aucun';
  }

  submitButton.onclick = function() {
    if (inputField.value) {
      localStorage.setItem('first_name', inputField.value);
      inputField.value = '';
    }
  }

}());
