$(document).ready(function() {

  var firstName = 'toto',
      apiKey = 'PKYMVKxessUwaTEnpWXEtkqME062neJH',
      baseUrl = 'https://api.mongolab.com/api/1/databases/toulouse',
      databaseUrl = baseUrl + '/collections/' + firstName + '?apiKey=' + apiKey;

  // Charge les commentaires existants.
  loadComments();

  $('#the_form').submit(function() {
    var comment = {
      author: $('#new_author').val(),
      content: $('#new_content').val(),
    };

    // Arrête le traitement si pas de valeur.
    if (!comment.author || !comment.content) {
      alert('Vous devez remplir tous les champs.');
    }
    else {
      saveComment(comment);
    }

    // Annule la soumission par défaut du navigateur.
    return false;
  });

  /**
   * Charge les commentaires précédemment enregistrés.
   */
  function loadComments() {
    $.getJSON(databaseUrl, function(data) {
      $.each( data, function(key, comment) {
        displayComment(comment);
      });
    });
  }

  /**
   * Insère le nouveau commentaire dans le DOM.
   */
  function displayComment(comment) {
    var newCommentHtml = '';
    newCommentHtml += '<div class="well comment">';
    newCommentHtml += comment.content;
    newCommentHtml += '<div class="signature">' + comment.author + '</div>';
    newCommentHtml += '</div>';
    $('#comments').append(newCommentHtml);
  }

  /**
   * Enregistre un nouveau commentaire sur Mongolab grâce à Ajax
   */
  function saveComment(comment) {
    $.ajax({
      url: databaseUrl,
      data: JSON.stringify(comment),
      type: "POST",
      contentType: "application/json"
    }).done(function(newComment) {
      displayComment(newComment);
      $('#new_author').val('');
      $('#new_content').val('');
    });
  }

});
